// ============================================================
//  EJERCICIO 1 - Misiones espaciales [1,5 puntos]
//  Escribe tu solución debajo de cada apartado.
//  Solo se permite usar métodos de array. No uses bucles for/while.
// ============================================================

const misiones = [
    {nombre: "Apollo 11", pais: "EEUU", anio: 1969, exitosa: true, tripulacion: 3},
    {nombre: "Sputnik 1", pais: "URSS", anio: 1957, exitosa: true, tripulacion: 0},
    {nombre: "Mars Climate", pais: "EEUU", anio: 1998, exitosa: false, tripulacion: 0},
    {nombre: "Vostok 1", pais: "URSS", anio: 1961, exitosa: true, tripulacion: 1},
    {nombre: "Challenger", pais: "EEUU", anio: 1986, exitosa: false, tripulacion: 7},
    {nombre: "Artemis I", pais: "EEUU", anio: 2022, exitosa: true, tripulacion: 0},
    {nombre: "Luna 9", pais: "URSS", anio: 1966, exitosa: true, tripulacion: 0},
];


// a) [0,5 puntos] ————————————————————————————————
// Filtra las misiones exitosas y devuelve solo sus nombres.

const filtro = misiones
.filter(elementos=>elementos.exitosa===true)
.map(elementos=>elementos.nombre)

console.log(filtro);
console.log("\n");
// b) [0,5 puntos] ————————————————————————————————
// ¿Cuántos astronautas en total participaron en misiones exitosas?
const total = misiones.reduce((acumulador,elemento)=>{
    return acumulador += elemento.tripulacion;
},0);
console.log(total)
console.log("\n");
// c) [0,5 puntos] ————————————————————————————————
// Encuentra la misión más reciente de toda la lista.
// Usa reduce(). No uses sort().

const reciente = misiones.reduce((acumulador,elemento)=>{
    if (elemento.anio>acumulador){
        return elemento.anio;
    }else{
        return acumulador;
    }
},0);
console.log(reciente);


